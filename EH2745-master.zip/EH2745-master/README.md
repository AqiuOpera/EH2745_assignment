# The assignment of EH2745 COMPUTER APPLICATIONS IN POWER SYSTEMS 
This is the file for the assignment of EH2745 COMPUTER APPLICATIONS IN POWER SYSTEMS 
Assignment_1_ver3.py is the final version of the assignment code, which contains the reading of XML-CIM file, create the lists of different devices, store data into the lists and traverse procedure.
video_ver2.mp4 is to explain how the Assignment_1_ver3.py works.
Assignment_1.ipynb is the jupyter version 
